# Kimera Live Games — Horse sprites V4

Five horse identities, eight frames each. PNG RGBA, 320×256, transparent background.

Copy the `horses/` directory to `public/games/horse-racing/assets/`.

Expected paths: `assets/horses/horse-01/frame-01.png` through `frame-08.png`, repeated for horses 02–05.

Suggested preview timing: 110 ms per frame; tune after testing in the game.
